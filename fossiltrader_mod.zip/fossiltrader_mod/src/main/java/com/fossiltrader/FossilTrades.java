package com.fossiltrader;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import net.minecraft.resources.ResourceLocation;

/**
 * Tabela de trocas: id do item, quantas esmeraldas custa e quantas unidades voce recebe.
 * Para mudar um preco, edite o numero (esmeraldas, quantidade) e recompile.
 * Itens de mods que nao estiverem instalados sao ignorados automaticamente.
 */
public final class FossilTrades {

    public record Trade(ResourceLocation item, int emeralds, int quantity) {}

    public static final List<Trade> ALL = new ArrayList<>();
    public static final Set<ResourceLocation> ITEM_IDS = new LinkedHashSet<>();

    private static void add(String namespace, String path, int emeralds, int quantity) {
        ResourceLocation id = new ResourceLocation(namespace, path);
        ALL.add(new Trade(id, emeralds, quantity));
        ITEM_IDS.add(id);
    }

    static {
        // --- Prehistoric Fauna ---
        add("prehistoricfauna", "triassic_fossil", 4, 1);
        add("prehistoricfauna", "jurassic_fossil", 4, 1);
        add("prehistoricfauna", "cretaceous_fossil", 4, 1);

        // --- Unusual Prehistory 1 ---
        add("unusualprehistory", "mezo_fossil", 4, 1);
        add("unusualprehistory", "paleo_fossil", 4, 1);
        add("unusualprehistory", "tar_fossil_item", 4, 1);
        add("unusualprehistory", "frozen_fossil_item", 4, 1);
        add("unusualprehistory", "opal_fossil", 4, 1);
        add("unusualprehistory", "amber_fossil", 8, 1);
        add("unusualprehistory", "plant_fossil_item", 16, 10);

        // --- Unusual Prehistory 2 - fosseis ---
        add("unusual_prehistory", "bristle_fossil", 10, 1);
        add("unusual_prehistory", "guillotine_fossil", 10, 1);
        add("unusual_prehistory", "jawless_fossil", 10, 1);
        add("unusual_prehistory", "anvil_fossil", 10, 1);
        add("unusual_prehistory", "mossy_fossil", 10, 1);
        add("unusual_prehistory", "boomerang_fossil", 10, 1);
        add("unusual_prehistory", "plow_fossil", 10, 1);
        add("unusual_prehistory", "fish_fossil", 10, 1);
        add("unusual_prehistory", "gluttonous_fossil", 10, 1);
        add("unusual_prehistory", "impervious_fossil", 10, 1);
        add("unusual_prehistory", "flat_back_fossil", 10, 1);
        add("unusual_prehistory", "arm_fossil", 10, 1);
        add("unusual_prehistory", "prickly_fossil", 10, 1);
        add("unusual_prehistory", "imperative_fossil", 10, 1);
        add("unusual_prehistory", "meltdown_fossil", 10, 1);
        add("unusual_prehistory", "wing_fossil", 10, 1);
        add("unusual_prehistory", "fury_fossil", 10, 1);
        add("unusual_prehistory", "runner_fossil", 10, 1);
        add("unusual_prehistory", "boar_tooth_fossil", 10, 1);
        add("unusual_prehistory", "rugose_fossil", 10, 1);
        add("unusual_prehistory", "surge_fossil", 10, 1);
        add("unusual_prehistory", "saw_fossil", 10, 1);
        add("unusual_prehistory", "cranium_fossil", 10, 1);
        add("unusual_prehistory", "dubious_fossil", 10, 1);
        add("unusual_prehistory", "trunk_mouse_fossil", 10, 1);
        add("unusual_prehistory", "crooked_beak_fossil", 10, 1);
        add("unusual_prehistory", "plumage_fossil", 10, 1);
        add("unusual_prehistory", "flipper_fossil", 10, 1);
        add("unusual_prehistory", "thermal_fossil", 10, 1);
        add("unusual_prehistory", "aged_feather", 10, 1);
        add("unusual_prehistory", "bennettitales_fossil", 10, 1);
        add("unusual_prehistory", "calamophyton_fossil", 10, 1);
        add("unusual_prehistory", "delitzschala_fossil", 10, 1);
        add("unusual_prehistory", "cooksonia_fossil", 10, 1);
        add("unusual_prehistory", "leefructus_fossil", 10, 1);
        add("unusual_prehistory", "quillwort_fossil", 10, 1);
        add("unusual_prehistory", "raiguenrayun_fossil", 10, 1);
        add("unusual_prehistory", "rhynia_fossil", 10, 1);
        add("unusual_prehistory", "ginkgo_fossil", 10, 1);
        add("unusual_prehistory", "lepidodendron_fossil", 10, 1);
        add("unusual_prehistory", "aethophyllum_fossil", 10, 1);
        add("unusual_prehistory", "brachyphyllum_fossil", 10, 1);
        add("unusual_prehistory", "cycad_fossil", 10, 1);
        add("unusual_prehistory", "guangdedendron_fossil", 10, 1);
        add("unusual_prehistory", "zhangsolva_fossil", 10, 1);
        add("unusual_prehistory", "prototaxites_fossil", 10, 1);
        add("unusual_prehistory", "tempskya_fossil", 10, 1);
        add("unusual_prehistory", "metasequoia_fossil", 10, 1);
        add("unusual_prehistory", "dryophyllum_fossil", 10, 1);
        add("unusual_prehistory", "mesozoic_fossil", 10, 1);
        add("unusual_prehistory", "paleozoic_fossil", 10, 1);
        add("unusual_prehistory", "cenozoic_fossil", 10, 1);
        add("unusual_prehistory", "holocene_fossil", 10, 1);
        add("unusual_prehistory", "plant_fossil", 10, 1);
        add("unusual_prehistory", "unknown_fossil", 10, 1);

        // --- Weird and Wonderful ---
        add("weirdandwonderful", "fishy_fang_fossil", 10, 1);
        add("weirdandwonderful", "frostburn_fossil", 10, 1);
        add("weirdandwonderful", "violent_fossil", 10, 1);
        add("weirdandwonderful", "pseudolphin_fossil", 10, 1);
        add("weirdandwonderful", "obnoxious_fossil", 10, 1);
        add("weirdandwonderful", "scorpio_fossil", 10, 1);
        add("weirdandwonderful", "rammer_fossil", 10, 1);

        // --- Unusual Prehistory 2 - construcao ---
        add("unusual_prehistory", "cobbled_fossilized_bone", 4, 4);
        add("unusual_prehistory", "cobbled_fossilized_bone_slab", 4, 4);
        add("unusual_prehistory", "cobbled_fossilized_bone_stairs", 4, 4);
        add("unusual_prehistory", "fossilized_bone_block", 4, 4);
        add("unusual_prehistory", "fossilized_bone_bark", 4, 4);
        add("unusual_prehistory", "fossilized_bone_rod", 4, 4);
        add("unusual_prehistory", "fossilized_bone_row", 4, 4);
        add("unusual_prehistory", "fossilized_bone_spike", 4, 4);
        add("unusual_prehistory", "fossilized_bone_vertebra", 4, 4);
        add("unusual_prehistory", "fossilized_skull", 4, 4);
        add("unusual_prehistory", "fossilized_skull_lantern", 4, 4);
        add("unusual_prehistory", "fossilized_skull_soul_lantern", 4, 4);
    }

    private FossilTrades() {}
}
