package com.fossiltrader;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;

@Mod(FossilTraderMod.MOD_ID)
public class FossilTraderMod {
    public static final String MOD_ID = "fossiltrader";

    public FossilTraderMod() {
        MinecraftForge.EVENT_BUS.register(new CartographerFossilHandler());
    }
}
