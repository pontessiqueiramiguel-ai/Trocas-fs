package com.fossiltrader;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Quando um jogador clica num Cartografo, ANTES da tela de troca abrir, garante que a lista de
 * trocas dele ja foi gerada (trocas normais) e acrescenta todas as trocas de fosseis no final.
 *
 * Nao usamos VillagerTradesEvent porque o jogo sorteia so 2 trocas de cada nivel; assim o
 * Cartografo recebe TODAS as trocas de fosseis.
 */
public class CartographerFossilHandler {

    /** Usos maximos: praticamente infinito, entao nao precisa de restock. */
    private static final int MAX_USES = 999_999;

    @SubscribeEvent
    public void onInteract(PlayerInteractEvent.EntityInteract event) {
        if (event.getLevel().isClientSide()) return;
        if (!(event.getTarget() instanceof Villager villager)) return;
        if (villager.getVillagerData().getProfession() != VillagerProfession.CARTOGRAPHER) return;

        // getOffers() gera as trocas normais do Cartografo se ainda nao existirem.
        MerchantOffers offers = villager.getOffers();
        if (hasFossilTrades(offers)) return;

        for (FossilTrades.Trade trade : FossilTrades.ALL) {
            if (!ForgeRegistries.ITEMS.containsKey(trade.item())) continue; // mod nao instalado
            Item item = ForgeRegistries.ITEMS.getValue(trade.item());
            if (item == null || item == Items.AIR) continue;

            offers.add(new MerchantOffer(
                    new ItemStack(Items.EMERALD, trade.emeralds()),
                    new ItemStack(item, trade.quantity()),
                    MAX_USES,
                    0,      // xp para o aldeao: 0, fosseis nao fazem ele subir de nivel
                    0.0F)); // priceMultiplier 0 = preco fixo (sem variacao por demanda)
        }
    }

    /** Ja tem trocas de fosseis? (evita duplicar; tambem recupera se a lista foi resetada) */
    private static boolean hasFossilTrades(MerchantOffers offers) {
        for (MerchantOffer offer : offers) {
            ResourceLocation id = ForgeRegistries.ITEMS.getKey(offer.getResult().getItem());
            if (id != null && FossilTrades.ITEM_IDS.contains(id)) return true;
        }
        return false;
    }
}
